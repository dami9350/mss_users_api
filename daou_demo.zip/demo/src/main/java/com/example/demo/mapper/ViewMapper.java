package com.example.demo.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.example.demo.domain.DepartmentMember;
import com.example.demo.domain.Member;
 
@Repository
public interface ViewMapper {
 
    List<DepartmentMember> findAll();

	void updateMemberProfileImg(Member member);

	List<Map<String, Object>> selectDeptMemberList(String code);
 
}