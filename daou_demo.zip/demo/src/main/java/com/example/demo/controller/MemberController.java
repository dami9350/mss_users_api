package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.domain.Member;
import com.example.demo.service.MemberService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping(value = "/api/member")
public class MemberController { // 2. 부서 관리

    private final MemberService memberService;

    @GetMapping(value = "")
    public ResponseEntity<List<Member>> findAll() {
        List<Member> member = memberService.findAll();
        return ResponseEntity.ok(member);
    }
 
    @GetMapping(value = "/{code}")
    public ResponseEntity<Member> findByCode(@PathVariable(value = "code") Long code) {
    	Member member = memberService.findByCode(code);
        return ResponseEntity.ok(member);
    }
 
    @PostMapping(value = "")
    public ResponseEntity<?> testSave(@RequestBody Member member) {
    	
        memberService.save(member);
        System.out.println("member : " + member.toString());
        HashMap<String, String> saveResult = new HashMap<>();
        saveResult.put("msg", "등록되었습니다.");
        saveResult.put("code", member.getCode().toString());
        return new ResponseEntity<>(saveResult, HttpStatus.OK);
    }
 
    @DeleteMapping(value = "/{code}")
    public ResponseEntity<?> testDelete(@PathVariable(value = "code") Long code) {
    	memberService.deleteByCode(code);
        
    	HashMap<String, String> saveResult = new HashMap<>();
        saveResult.put("msg", "삭제되었습니다.");
        return new ResponseEntity<>(saveResult, HttpStatus.OK);
    }
 
    @PutMapping(value = "/{code}")
    public ResponseEntity<?> testUpdate(@PathVariable(value = "code") Long code, @RequestBody Member member) {
    	//Department oldDepartment = departmentService.findByCode(code);
    	member.setCode(code);
    	memberService.update(member);
        
    	HashMap<String, String> saveResult = new HashMap<>();
        saveResult.put("msg", "수정되었습니다.");
        return new ResponseEntity<>(saveResult, HttpStatus.OK);
    }

}
