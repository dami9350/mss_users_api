package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.domain.DepartmentMember;
import com.example.demo.mapper.DepartmentMemberMapper;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class DepartmentMemberService {

	private final DepartmentMemberMapper departmentMemberMapper;
	
	public int findByCode(Long code) {
        return departmentMemberMapper.findByCode(code);
    }
	
    public void save(DepartmentMember departmentMember) {
    	departmentMemberMapper.save(departmentMember);
    }
 
    public void deleteByCode(Long code) {
    	departmentMemberMapper.deleteByCode(code);
    }
	
}
