package com.example.demo.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.domain.Member;
 
@Repository
public interface MemberMapper {
 
    List<Member> findAll();
 
    Member findByCode(Long code);
 
    int save(Member member);
 
    void update(Member member);
 
    void deleteByCode(Long code);
 
}