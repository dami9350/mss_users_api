package com.example.demo.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.domain.Department;
 
@Repository
public interface DepartmentMapper {
 
    List<Department> findAll();
 
    Department findByCode(Long code);
 
    void save(Department department);
 
    void update(Department department);
 
    void deleteByCode(Long code);
 
}