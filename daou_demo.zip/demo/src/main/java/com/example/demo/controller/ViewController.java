package com.example.demo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.domain.Member;
import com.example.demo.service.ViewService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping(value = "/")
public class ViewController {
	
	private final ViewService viewService;
	
	@GetMapping(value = "/main")
    public ModelAndView viewMain() {
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("main");
		mav.addObject("list", viewService.findAll());
		
		System.out.println("list : " + viewService.findAll().toString());
		
		return mav;
    }
	
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/deptList")
    public ModelAndView deptList(HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
        HttpEntity<?> entity = new HttpEntity<>(header);
		HttpEntity httpEntity = restTemplate.exchange("http://localhost:8080/api/dept", HttpMethod.GET, entity, List.class);
		
		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
		resultList = (List<Map<String, Object>>)httpEntity.getBody();
		
		mav.addObject("list", resultList);
		mav.setViewName("dept/list");
		
		return mav;
    }
	
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/deptDetail")
    public ModelAndView deptDetail(HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		
		if(request.getParameter("code") != null && !"".equals(request.getParameter("code").toString())){
			String code = request.getParameter("code").toString();
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders header = new HttpHeaders();
	        HttpEntity<?> entity = new HttpEntity<>(header);
			HttpEntity httpEntity = restTemplate.exchange("http://localhost:8080/api/dept/" + code, HttpMethod.GET, entity, Map.class);
			
			Map<String, Object> reusltMap = new HashMap<String, Object>();
			reusltMap = (Map<String, Object>)httpEntity.getBody();
			
			httpEntity = restTemplate.exchange("http://localhost:8080/api/dept", HttpMethod.GET, entity, List.class);
			
			List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
			resultList = (List<Map<String, Object>>)httpEntity.getBody();
			
			mav.addObject("department", reusltMap);
			mav.addObject("list", resultList);
		}

		mav.setViewName("dept/detail");
		
		return mav;
    }
	
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/deptInsertForm")
    public ModelAndView deptInsertForm(HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
        HttpEntity<?> entity = new HttpEntity<>(header);
		HttpEntity httpEntity = restTemplate.exchange("http://localhost:8080/api/dept", HttpMethod.GET, entity, List.class);
		
		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
		resultList = (List<Map<String, Object>>)httpEntity.getBody();
		
		mav.addObject("list", resultList);
		
		mav.setViewName("dept/insertForm");
		
		return mav;
    }
	
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/memberList")
    public ModelAndView memberManagement(HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
        HttpEntity<?> entity = new HttpEntity<>(header);
		HttpEntity httpEntity = restTemplate.exchange("http://localhost:8080/api/member", HttpMethod.GET, entity, List.class);
		
		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
		resultList = (List<Map<String, Object>>)httpEntity.getBody();
		
		System.out.println("resultList : " + resultList.toString());
		
		mav.addObject("list", resultList);
		mav.setViewName("member/list");
		
		return mav;
    }

	@SuppressWarnings("unchecked")
	@GetMapping(value = "/memberDetail")
    public ModelAndView memberDetail(HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		
		if(request.getParameter("code") != null && !"".equals(request.getParameter("code").toString())){
			String code = request.getParameter("code").toString();
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders header = new HttpHeaders();
	        HttpEntity<?> entity = new HttpEntity<>(header);
			HttpEntity httpEntity = restTemplate.exchange("http://localhost:8080/api/member/" + code, HttpMethod.GET, entity, Map.class);
			
			Map<String, Object> reusltMap = new HashMap<String, Object>();
			reusltMap = (Map<String, Object>)httpEntity.getBody();
			
			mav.addObject("member", reusltMap);
		}

		mav.setViewName("member/detail");
		
		return mav;
    }
	
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/memberInsertForm")
    public ModelAndView memberInsertForm(HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
        HttpEntity<?> entity = new HttpEntity<>(header);
		HttpEntity httpEntity = restTemplate.exchange("http://localhost:8080/api/member", HttpMethod.GET, entity, List.class);
		
		List<Map<String, Object>> resultList = new ArrayList<Map<String, Object>>();
		resultList = (List<Map<String, Object>>)httpEntity.getBody();
		
		mav.addObject("list", resultList);
		
		mav.setViewName("member/insertForm");
		
		return mav;
    }
	
	@PostMapping("/api/memberProfileImgInsert")
	public ResponseEntity<?> memberProfileImgInsert(@RequestParam(value = "profileImg", required = false) List<MultipartFile> imageList, HttpServletRequest request) throws IOException {
		
	    String webPath = "resources/images/";
	    String folderPath = request.getSession().getServletContext().getRealPath(webPath);
	    
	    if(request.getParameter("code") != null && !"".equals(request.getParameter("code").toString())){
	    	String code = request.getParameter("code").toString();
	    	viewService.insertMemberProfileImg(code, imageList, request);
	    	
	    	HashMap<String, String> saveResult = new HashMap<>();
	        saveResult.put("msg", "등록되었습니다.");
	        return new ResponseEntity(saveResult, HttpStatus.OK);
	    } else {
	    	HashMap<String, String> saveResult = new HashMap<>();
	        saveResult.put("msg", "회원코드가 없습니다.");
	        return new ResponseEntity(saveResult, HttpStatus.BAD_REQUEST);
	    }

	}
}
