package com.example.demo.domain;

import lombok.Data;

@Data
public class Department {
	
	private Long code;
	private String name;
	private Long parentCode;
	private String parentName;


}
