package com.example.demo.service;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.domain.DepartmentMember;
import com.example.demo.domain.Member;
import com.example.demo.mapper.ViewMapper;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class ViewService {

	private final ViewMapper viewMapper;
	
    public List<DepartmentMember> findAll() {
        return viewMapper.findAll();
    }

	public void insertMemberProfileImg(String code, List<MultipartFile> imageList, HttpServletRequest request) {
		String webPath = "images/";
        String folderPath = request.getSession().getServletContext().getRealPath(webPath);
    	
    	for (int i = 0; i < imageList.size(); i++) {
			if (imageList.get(i).getSize() > 0) {	
				String reName = rename(imageList.get(i).getName());
				
				try {
					imageList.get(i).transferTo(new File(folderPath + reName));
					
					Member member = new Member();
					member.setCode(Long.parseLong(code));
					member.setProfileImg("/" + webPath + reName);
					viewMapper.updateMemberProfileImg(member);
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
    	}
	}
	
	public String rename(String fileName) {
    	long currentTime = System.currentTimeMillis();
    	SimpleDateFormat simDf = new SimpleDateFormat("yyyyMMddHHmmss");
    	int randomNumber = (int)(Math.random()*100000);

    	String uniqueFileName = "" + randomNumber + simDf.format(new Date(currentTime));

    	@SuppressWarnings("unused")
		String body = null;
    	String ext = null;

    	int dot = fileName.lastIndexOf(".");
    	if (dot != -1) {
	    	body = fileName.substring(0, dot);
	    	ext = fileName.substring(dot); // includes "."
    	}
    	else {
	    	body = fileName;
	    	ext = "";
    	}

    	String tempName = uniqueFileName + ext;

    	return tempName;
    }

	public List<Map<String, Object>> selectDeptMemberList(String code) {
		return viewMapper.selectDeptMemberList(code);
	}
}
