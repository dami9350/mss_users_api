package com.example.demo.controller;

import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.domain.Department;
import com.example.demo.domain.DepartmentMember;
import com.example.demo.service.DepartmentMemberService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping(value = "/api/deptMember")
public class DepartmentMemberController { // 2. 부서 관리

    private final DepartmentMemberService departMembermentService;
 
    @GetMapping(value = "/{code}")
    public ResponseEntity<?> findByCode(@PathVariable(value = "code") Long code) {
    	int cnt = departMembermentService.findByCode(code);
    	
    	HashMap<String, String> saveResult = new HashMap<>();
        saveResult.put("cnt", String.valueOf(cnt));
        return new ResponseEntity(saveResult, HttpStatus.OK);
    }
    
    @PostMapping(value = "")
    public ResponseEntity<?> testSave(@RequestBody DepartmentMember departmentMember) {
    	departMembermentService.save(departmentMember);
        
        HashMap<String, String> saveResult = new HashMap<>();
        saveResult.put("msg", "등록되었습니다.");
        return new ResponseEntity(saveResult, HttpStatus.OK);
    }
 
    @DeleteMapping(value = "/{code}")
    public ResponseEntity<?> testDelete(@PathVariable(value = "code") Long code) {
    	departMembermentService.deleteByCode(code);
        
    	HashMap<String, String> saveResult = new HashMap<>();
        saveResult.put("msg", "삭제되었습니다.");
        return new ResponseEntity(saveResult, HttpStatus.OK);
    }


}
