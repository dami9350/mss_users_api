package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.domain.Department;
import com.example.demo.mapper.DepartmentMapper;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class DepartmentService {

	private final DepartmentMapper departmentMapper;
	
    public List<Department> findAll() {
        return departmentMapper.findAll();
    }
 
    public Department findByCode(Long code) {
        return departmentMapper.findByCode(code);
    }
 
    public void save(Department department) {
    	departmentMapper.save(department);
    }
 
    public void update(Department department) {
    	departmentMapper.update(department);
    }
 
    public void deleteByCode(Long code) {
    	departmentMapper.deleteByCode(code);
    }
	
}
