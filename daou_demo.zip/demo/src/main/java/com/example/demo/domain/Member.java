package com.example.demo.domain;

import lombok.Data;

@Data
public class Member {

	private Long code;
	private String name;
	private String position;
	private String profileImg;
}
