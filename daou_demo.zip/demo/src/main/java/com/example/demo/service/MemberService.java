package com.example.demo.service;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.taglibs.standard.tag.common.core.Util;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.domain.Member;
import com.example.demo.mapper.MemberMapper;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class MemberService {

	private final MemberMapper memberMapper;
	
    public List<Member> findAll() {
        return memberMapper.findAll();
    }
 
    public Member findByCode(Long code) {
        return memberMapper.findByCode(code);
    }
 
    public int save(Member member) {
    	return memberMapper.save(member);
    }
 
    public void update(Member member) {
    	memberMapper.update(member);
    }
 
    public void deleteByCode(Long code) {
    	memberMapper.deleteByCode(code);
    }

}
