package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.domain.Member;
import com.example.demo.mapper.MemberMapper;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class MemberService {

	private final MemberMapper memberMapper;
	
    public List<Member> findAll() {
        return memberMapper.findAll();
    }
 
    public Member findByCode(Long code) {
        return memberMapper.findByCode(code);
    }
 
    public void save(Member member) {
    	memberMapper.save(member);
    }
 
    public void update(Member member) {
    	memberMapper.update(member);
    }
 
    public void deleteByCode(Long code) {
    	memberMapper.deleteByCode(code);
    }

}
