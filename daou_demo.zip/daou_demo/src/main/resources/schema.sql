--
-- 부서
--
DROP TABLE IF EXISTS DEPARTMENT;

CREATE TABLE DEPARTMENT COMMENT '부서' (
    CODE        INT          NOT NULL   AUTO_INCREMENT    COMMENT '부서코드' 
  , NAME        VARCHAR(100) NOT NULL                     COMMENT '부서명'
  , PARENT_CODE INT          NOT NULL DEFAULT 0           COMMENT '상위 부서코드'
  , PRIMARY KEY (CODE)
);

DROP TABLE IF EXISTS MEMBER;

CREATE TABLE MEMBER COMMENT '직원' (
    CODE        INT          NOT NULL   AUTO_INCREMENT    COMMENT '직원코드' 
  , NAME        VARCHAR(100) NOT NULL                     COMMENT '직원명'
  , POSITION    VARCHAR(100)                              COMMENT '직급'
  , PROFILE_IMG VARCHAR(500)                              COMMENT '프로필 이미지'
  , PRIMARY KEY (CODE)
);

DROP TABLE IF EXISTS DEPARTMENT_MEMBER;

CREATE TABLE DEPARTMENT_MEMBER COMMENT '부서-직원 매핑' (
    CODE                INT    NOT NULL   AUTO_INCREMENT    COMMENT '부서-직원 코드' 
  , DEPARTMENT_CODE     INT    NOT NULL                     COMMENT '부서코드'
  , MEMBER_CODE         INT    NOT NULL                     COMMENT '직원코드'
  , PRIMARY KEY (CODE)
);