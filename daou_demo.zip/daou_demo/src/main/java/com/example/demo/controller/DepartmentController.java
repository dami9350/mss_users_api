package com.example.demo.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.domain.Department;
import com.example.demo.service.DepartmentService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@CrossOrigin
@RequestMapping(value = "/api/dept")
public class DepartmentController { // 2. 부서 관리

    private final DepartmentService departmentService;

    @GetMapping(value = "")
    public ResponseEntity<List<Department>> findAll() {
        List<Department> department = departmentService.findAll();
        return ResponseEntity.ok(department);
    }
 
    @GetMapping(value = "/{code}")
    public ResponseEntity<Department> findByCode(@PathVariable(value = "code") Long code) {
    	Department department = departmentService.findByCode(code);
        return ResponseEntity.ok(department);
    }
 
    @PostMapping(value = "")
    public ResponseEntity<?> testSave(@RequestBody Department department) {
        departmentService.save(department);
        return ResponseEntity.ok("saved");
    }
 
    @DeleteMapping(value = "/{code}")
    public ResponseEntity<?> testDelete(@PathVariable(value = "code") Long code) {
    	departmentService.deleteByCode(code);
        return ResponseEntity.ok("deleted");
    }
 
    @PutMapping(value = "/{code}")
    public ResponseEntity<?> testUpdate(@PathVariable(value = "code") Long code, @RequestBody Department department) {
    	//Department oldDepartment = departmentService.findByCode(code);
    	department.setCode(code);
        departmentService.update(department);
        return ResponseEntity.ok("updated");
    }

}
