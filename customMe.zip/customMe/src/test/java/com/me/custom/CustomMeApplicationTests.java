package com.me.custom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomMeApplicationTests {

	@Test
	void contextLoads() {
	}

}
