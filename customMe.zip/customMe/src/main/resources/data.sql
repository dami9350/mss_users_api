--
-- 원료
--
INSERT INTO MATERIAL
    (NAME, AMOUNT, STATUS)
VALUES 
       ('A', 10, 1)
     , ('B', 200, 1)
     , ('C', 200, 1)
     , ('D', 200, 1)
;