package com.me.custom.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.me.custom.domain.Material;
import com.me.custom.domain.Order;
import com.me.custom.mapper.MaterialMapper;
import com.me.custom.mapper.OrderMapper;
import com.me.custom.utils.ComUtils;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class OrderService {

	Logger log = LoggerFactory.getLogger(this.getClass());
	
	private final OrderMapper orderMapper;
	
	private final MaterialMapper materialMapper;
	
    public List<Order> findAll() {
        return orderMapper.findAll();
    }
 
    public Order findByOrderNumber(String orderNumber) {
        return orderMapper.findByOrderNumber(orderNumber);
    }
 
    public void save(Order order) {
    	// 주문번호 중복 체크
    	if(orderMapper.findCountByOrderNumber(order.getOrder_number()) > 0) {
    		order.setOrder_status("0");
    		order.setError("주분번호 중복");
    		return;
    	}
    	log.info("################2");
    	if(ComUtils.checkWorkTime()) {
    		// 근무 시간 일때 금일 생산 갯수 확인
    		//LocalDateTime now = LocalDateTime.now();
        	//order.setOrder_date(now);
    		//String nowDate = now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    		//int todayCnt = orderMapper.findByToday(nowDate);
    		int todayCnt = orderMapper.findByStatus("2");
    		if(todayCnt < 30) {
    			// 효능 validation 체크 및 재고 체크
    			
    			String orderCode = order.getOrder_code();
    			
    			String order1 = "";
    			String order2 = "";
    			
    			int order1Amount = 0;
    			int order2Amount = 0;
    			
    			try {
	    			order1 = orderCode.substring(0, 1);
	    			order1Amount = Integer.parseInt(orderCode.substring(1, 2));
	    			if(order1Amount == 1 && "0".equals(orderCode.substring(2, 3))) {
	    				order1Amount = Integer.parseInt(orderCode.substring(1, 3));
	    			} else {
	    				order2 = orderCode.substring(2, 3);
	    				order2Amount = Integer.parseInt(orderCode.substring(3, 4));
	    			}
    			} catch(Exception e) {
    				// 효능 validation 체크 에러
    				order.setOrder_status("0");
					order.setError("주문 코드 에러");
    				return;
    			}
    			
    			if((order1Amount + order2Amount) != 10) {
    				// 효능 validation 체크 에러
    				order.setOrder_status("0");
    				order.setError("주문 코드 에러");
    				return;
    			}
    			
    			Material material = materialMapper.findByName(order1);
    			if(material != null) {
    				if(material.getAmount() - order1Amount >= 0) {
    					if(!"".equals(order2)) {
    						Material material2 = materialMapper.findByName(order2);
    						if(material2 != null) {
    		    				if(material2.getAmount() - order2Amount >= 0) {
    		    					// 원료 보충중인게 있는지 체크
    		    					int supplyCnt = materialMapper.findByStatus("2");
    		    					if(supplyCnt > 0) {
    		    						order.setOrder_status("1");
    		    					} else {
    		    						// 원료1 재고 차감
    		    						material.setAmount(material.getAmount() - order1Amount);
    		    						materialMapper.updateAmount(material);
    		    						
    		    						// 원료2 재고 차감
    		    						material2.setAmount(material2.getAmount() - order2Amount);
    		    						materialMapper.updateAmount(material2);
    		    						order.setOrder_status("2");
    			    					order.setSend_date(LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyyMMdd")));
    		    					}
    		    				} else {
    		    					// 원료 보충
    		    					LocalDateTime maxSupplyDate = materialMapper.findMaxSupplyDateByStatus("2");
    		    					material2.setSupply_date(maxSupplyDate.plusSeconds(40));
    		    					material2.setStatus("2");
    		    					materialMapper.updateStatus(material2);
    		    					
    		    					order.setOrder_status("1");
    		    				}
    						} else {
    							// 효능 단종
    							order.setOrder_status("0");
    		    				order.setError("효능 단종");
    						}
    					} else {
    						// 원료 보충중인게 있는지 체크
	    					int supplyCnt = materialMapper.findByStatus("2");
	    					if(supplyCnt > 0) {
	    						order.setOrder_status("1");
	    					} else {
	    						// 원료1 재고 차감
	    						material.setAmount(material.getAmount() - order1Amount);
	    						materialMapper.updateAmount(material);
	    						
	    						order.setOrder_status("2");
		    					order.setSend_date(LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyyMMdd")));
	    					}
    					}
    				} else {
    					// 원료 보충
    					LocalDateTime maxSupplyDate = materialMapper.findMaxSupplyDateByStatus("2");
    					material.setSupply_date(maxSupplyDate.plusSeconds(40));
    					material.setStatus("2");
    					materialMapper.updateStatus(material);
    					
    					order.setOrder_status("1");
    				}
    				
    			} else {
    				// 효능 단종
    				order.setOrder_status("0");
    				order.setError("효능 단종");
    			}
    			
    			
    		} else {
    			// 금일 생산 갯수가 30개 이상일 경우 대기 후 다음날 생산
    			order.setOrder_status("1");
    		}
    	} else {
    		// 근무 외 시간
    		// 대기 후 다음날 생산
    		order.setOrder_status("1");
    	}
    	/*
    	 * 
주문 -> 근무시간 확인(9~17) -> O 금일 생산된 제품이 30개 이상인지 체크 효능 있는지 체크 -> O 효능 재고 체크  -> O 원료 보충중인지 체크 -> 제품 생산 완료 -> 근무 시간 종료된 후 발송
                       -> X 대기(다음날 생산)                             -> X 대기(다음날 생산)-> X 보충중인 원료가 있는지 체크(한번에 한 종류의 원료만 보충 가능) -> O 원료 보충(40분)
					                                                                                                                        -> 대기 후 원료 보충
    	 */
    	orderMapper.save(order);
    	log.info("============================");
    	log.info("주문 내역 : " + order.toString());
    	log.info("============================");
    }
 
    public void updateSendDate(Order order) {
    	orderMapper.updateSendDate(order);
    }
    
    public void updateOrderStatus(Order order) {
    	orderMapper.updateOrderStatus(order);
    }
 
    public void deleteByOrderNumber(String orderNumber) {
    	orderMapper.deleteByOrderNumber(orderNumber);
    }
	
}
