package com.me.custom.utils;

import java.time.Duration;
import java.time.LocalDateTime;

public class ComUtils implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	
	private static final LocalDateTime startDate = LocalDateTime.of(2022, 11, 15, 11, 0);
	private static final long workSeconds = 480;
	private static final long offSeconds = 30;
	
	public static boolean checkWorkTime() {
		// 하루 8시간 근무 : 1분을 1초로 간주 (480초)
		// 근무시간 외 16시간은 30초로 간주
		// 하루 510초
		// 하루 중 근무외시간 비중 30 / 480 = 0.0625
		LocalDateTime now = LocalDateTime.now();
		
		Duration duration = Duration.between(startDate, now);
		long durationSeconds = duration.getSeconds();
		
		// 근무외 시간
		if((durationSeconds % (workSeconds + offSeconds)) >= workSeconds) {
			return false;
		}
		
		return true;
	}
}
