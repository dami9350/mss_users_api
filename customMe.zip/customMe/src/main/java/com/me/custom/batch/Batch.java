package com.me.custom.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.me.custom.domain.Material;
import com.me.custom.mapper.MaterialMapper;
import com.me.custom.mapper.OrderMapper;
import com.me.custom.utils.ComUtils;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class Batch {

	Logger log = LoggerFactory.getLogger(this.getClass());
	
	private final OrderMapper orderMapper;
	
	private final MaterialMapper materialMapper;
	
	// 근무외 시간 1번만 실행 되도록 처리할 변수
	private static boolean checkOffTimeOnlyOne = false;
	
	@Scheduled(fixedRate=1000) // 단위: ms
	public void fixedRateScheduler() {
	  
		// 원료 보츙 처리
		Material material =  materialMapper.findBySupplyDate();
		if(material != null) {
			material.setAmount(20);
			material.setStatus("1");
			material.setSupply_date(null);
			materialMapper.updateSupplyInfo(material);
			log.info("============================");
			log.info("[ " + material.getName() + " 원료 보충 완료] " + material.toString());
			log.info("============================");
			
			
		}
		
		// 근무외 시간 처리
		if(!ComUtils.checkWorkTime()) {
			if(!checkOffTimeOnlyOne) {
				orderMapper.updateSendStatus();
				log.info("============================");
				log.info("[근무외 시간] 제품 생산 중인 건들 -> 발송 완료");
				log.info("============================");
				
				orderMapper.updateProduceStatus();
				log.info("============================");
				log.info("[근무외 시간] 주문 접수 -> 제품 생산 중(최대 30개)");
				log.info("============================");
				checkOffTimeOnlyOne = true;
			}
		} else {
			if(checkOffTimeOnlyOne) {
				checkOffTimeOnlyOne = false;
			}
		}
	}
}
