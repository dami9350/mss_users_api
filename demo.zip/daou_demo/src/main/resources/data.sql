--
-- 부서
--
INSERT INTO DEPARTMENT
    (CODE, NAME, PARENT_CODE)
VALUES (1, '총무팀', 0)
     , (2, '개발센터', 0)
     , (3, '사방넷개발1팀', 2)
     , (4, '사방넷개발2팀', 2)
     , (5, '사방넷시스템팀', 2)
     , (6, '시스템1팀', 5)
     , (7, '시스템2팀', 5)
     , (8, '인사팀', 0)
;

--
-- 직원
--
INSERT INTO MEMBER
    (CODE, NAME, POSITION, PROFILE_IMG)
VALUES (1, '홍길동', '사장', NULL)
     , (2, '아무개', '이사', NULL)
     , (3, '원빈', '부장', NULL)
     , (4, '장동건', '과장', NULL)
     , (5, '현빈', '대리', NULL)
     , (6, '태연', '사원', NULL)
     , (7, '티파니', '부장', NULL)
     , (8, '윤아', '차장', NULL)
     , (9, '서현', '과장', NULL)
;

--
-- 부서-직원 매핑
--
INSERT INTO DEPARTMENT_MEMBER
    (CODE, DEPARTMENT_CODE, MEMBER_CODE)
VALUES (1, 0, 1)
     , (2, 2, 2)
     , (3, 4, 3)
     , (4, 4, 4)
     , (5, 4, 5)
     , (6, 4, 6)
     , (7, 5, 7)
     , (8, 6, 8)
     , (9, 6, 9)
;