package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.domain.DepartmentMember;
import com.example.demo.mapper.ViewMapper;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class ViewService {

	private final ViewMapper viewMapper;
	
    public List<DepartmentMember> findAll() {
        return viewMapper.findAll();
    }
}
