package com.example.demo.domain;

import lombok.Data;

@Data
public class DepartmentMember {
	
	private Long code;
	private Long departmentCode;
	private Long departmentParentCode;
	private Long memberCode;
	private String departmentName;
	private String memberName;
	private String position;
	private String profileImg;


}
