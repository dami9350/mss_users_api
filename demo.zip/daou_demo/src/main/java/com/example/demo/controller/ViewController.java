package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.service.ViewService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping(value = "/")
public class ViewController {
	
	private final ViewService viewService;
	
	@GetMapping(value = "/main")
    public ModelAndView viewMain() {
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("main");
		mav.addObject("list", viewService.findAll());
		
		System.out.println("list : " + viewService.findAll().toString());
		
		return mav;
    }
}
