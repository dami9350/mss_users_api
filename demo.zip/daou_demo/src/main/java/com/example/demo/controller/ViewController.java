package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.domain.Department;
import com.example.demo.domain.Member;
import com.example.demo.service.ViewService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Controller
@RequestMapping(value = "/")
public class ViewController {
	
	private final ViewService viewService;
	
	@GetMapping(value = "/main")
    public ModelAndView viewMain() {
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("main");
		mav.addObject("list", viewService.findAll());
		
		System.out.println("list : " + viewService.findAll().toString());
		
		return mav;
    }
	
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/deptList")
    public ModelAndView deptManagement(HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
        HttpEntity<?> entity = new HttpEntity<>(header);
		HttpEntity httpEntity = restTemplate.exchange("http://localhost:8080/api/dept", HttpMethod.GET, entity, List.class);
		
		List<Department> resultList = new ArrayList<Department>();
		resultList = (List<Department>)httpEntity.getBody();
		
		System.out.println("resultList : " + resultList.toString());
		
		mav.addObject("list", resultList);
		mav.setViewName("dept/list");
		
		return mav;
    }
	
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/deptInsertForm")
    public ModelAndView deptInsertForm(HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
        HttpEntity<?> entity = new HttpEntity<>(header);
		HttpEntity httpEntity = restTemplate.exchange("http://localhost:8080/api/dept", HttpMethod.GET, entity, List.class);
		
		List<Department> resultList = new ArrayList<Department>();
		resultList = (List<Department>)httpEntity.getBody();
		
		System.out.println("resultList : " + resultList.toString());
		
		mav.addObject("list", resultList);
		
		mav.setViewName("dept/insertForm");
		
		return mav;
    }
	
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/memberList")
    public ModelAndView memberManagement(HttpServletRequest request) {
		
		ModelAndView mav = new ModelAndView();
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders header = new HttpHeaders();
        HttpEntity<?> entity = new HttpEntity<>(header);
		HttpEntity httpEntity = restTemplate.exchange("http://localhost:8080/api/member", HttpMethod.GET, entity, List.class);
		
		List<Member> resultList = new ArrayList<Member>();
		resultList = (List<Member>)httpEntity.getBody();
		
		System.out.println("resultList : " + resultList.toString());
		
		mav.addObject("list", resultList);
		mav.setViewName("member/list");
		
		return mav;
    }
}
