package com.example.demo.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.domain.DepartmentMember;
 
@Repository
public interface ViewMapper {
 
    List<DepartmentMember> findAll();
 
}