package com.example.demo.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Department {
	
	private Long code;
	private String name;
	private Long parentCode;


}
